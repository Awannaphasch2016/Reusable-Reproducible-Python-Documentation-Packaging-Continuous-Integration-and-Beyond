iter-together
==============
A package that helps you iterate though parallel files

sources: https://www.youtube.com/watch?v=lo_g-GbYtaA&amp;t=8706s

Installation
--------------
if you want to download and install it in develpemnt mode
do this is your favrotie shell:


Installation
----------------
.. code-block:: sh

    git clone <this github repo>
    cd iter-together
    pip install -e .

Testing
----------------
.. code-block:: sh

    pip install tox
    tox

Documentation
----------------

Usage
--------




