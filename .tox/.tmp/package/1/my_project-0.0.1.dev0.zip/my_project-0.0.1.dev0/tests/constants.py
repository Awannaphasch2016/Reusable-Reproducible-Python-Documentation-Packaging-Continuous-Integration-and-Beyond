import os
import pathlib

HERE = pathlib.Path(os.path.dirname(__file__))

FILE1_PATH = HERE / 'f1.csv'
FILE2_PATH = HERE / 'f2.csv'
